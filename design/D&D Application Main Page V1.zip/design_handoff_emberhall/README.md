# Handoff: Emberhall — Landing Page & Campaign Dashboard

## Overview
Emberhall is a D&D campaign companion app. This package documents two screens:
1. **Landing page** — marketing entry with logo lockup, hero, feature strip, and a login / create-account modal.
2. **Campaign dashboard** — the signed-in home: active campaign hero, party roster, chronicle (activity feed), next-session countdown, a functional dice roller, and quick actions.

Both share one visual system ("candlelit dark fantasy"): near-black warm backgrounds, a gold ember accent, Cinzel (display) + Spectral (body), and soft radial glows.

## About the Design Files
The files in this bundle (`Emberhall Landing.dc.html`, `Emberhall Dashboard.dc.html`) are **design references created in HTML** — prototypes showing the intended look and behavior. They are **not** production code to copy directly. The task is to **recreate these designs inside your existing app's environment** (e.g. React + your styling solution) using its established components, patterns, and routing. Match the visuals and interactions described below; don't ship the raw HTML.

> Note: the prototypes are authored as "Design Components" with a small custom runtime (`support.js`) and a drag-drop `image-slot.js` web component. Those are prototyping helpers — ignore them when implementing. Replace `<image-slot>` with your own `<img>` / background-image.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, and interactions are specified. Recreate the UI pixel-accurately using your codebase's libraries and patterns. Where a value isn't listed, match what you see in the HTML.

---

## Design Tokens

### Color
| Token | Hex | Use |
|---|---|---|
| `bg.base` | `#0d0906` (landing) / `#100c08` (dashboard) | Page background base |
| `bg.radialWarm` | `#2a1a0d` → `#160f09` → base | Top radial page glow |
| `panel.from` | `#1f1810` (rgba .85–.92) | Card/section gradient top |
| `panel.to` | `#16100a` / `#160f09` (rgba .85–.92) | Card/section gradient bottom |
| `panel.deep` | `rgba(12,8,5,.4–.6)` | Inset wells, inputs, dice faces |
| `gold` | `#d9a441` | Primary accent / dots |
| `gold.bright` | `#ecc265` | Highlight gold (sigil, numbers, active) |
| `gold.deep` | `#cf962f` / `#bd8329` / `#c98a2b` | Gradient bottom of gold buttons |
| `ember.orange` | `#d97c31` / `#c97a2b` | Ember glow, sparks |
| `text.primary` | `#f6ecd9` / `#f3e9d6` / `#f0e6d3` | Headings |
| `text.body` | `#cdbfa6` / `#ddcfb5` / `#dccfb6` | Body copy |
| `text.muted` | `#9a8d78` | Labels, secondary |
| `text.faint` | `#857a68` / `#6f6353` | Timestamps, footer |
| `sage` | `#7f9a5b` / `#8fb15f` (bright) / `#b6cd92` (text) | Success / healthy HP / crit / "active" |
| `crimson` | `#c0563f` / `#c0563f` | Danger / low HP / crit-fail |
| `amber.warn` | `#d99a3c` | Mid HP |

Accent borders are gold at low alpha: `rgba(217,164,65,.12 / .14 / .16 / .22 / .28 / .3 / .45 / .5 / .6)` depending on emphasis.

### Typography
- **Display:** `Cinzel`, serif — weights 500/600/700/800. Used for logo wordmark, headings, numbers, button labels. Letter-spacing on the wordmark: `.16em`.
- **Body:** `Spectral`, serif — weights 300/400/500/600 (+ italic 400). Used for paragraphs, inputs, secondary text.
- Google Fonts import: `Cinzel:wght@500;600;700;800` + `Spectral:ital,wght@0,300;0,400;0,500;0,600;1,400`.
- Eyebrow/label style: 11.5–12px, `letter-spacing:.14em–.22em`, `text-transform:uppercase`, color `text.muted`.

### Spacing / Radius / Shadow
- Card radius: **16–20px**; buttons/inputs **11–13px**; pills **99px**; medallions **12–14px**.
- Page max-width (landing): **1180px**, padding `26–40px`.
- Standard section padding: `24–28px`.
- Gold button shadow: `0 10–12px 26–30px rgba(217,164,65,.34–.36)`.
- Card shadow: `0 24–30px 60–70px rgba(0,0,0,.5–.6)`.
- Radial glow pattern: `radial-gradient(circle, rgba(217,124,49,.32–.45), transparent 65–70%)`.

### The "E" sigil (logo mark)
Square, radius 12–14px. Background `radial-gradient(circle at 35% 30%, #ecc265, #c98a2b)`. Shadow `0 0 22px rgba(217,164,65,.45), inset 0 0 8px rgba(255,255,255,.35)`. Centered Cinzel 800 "E" in `#2a1a08`. Sizes: 42px (header), 46px (dashboard sidebar), 52px (modal).

---

## Screen 1 — Landing Page

**Layout:** vertical flow, centered max-width 1180px. Header → hero (2-col grid) → feature strip (3-col) → footer. Animated ember particles float upward across the whole page (decorative, `position:absolute` layer, `pointer-events:none`).

### Header
- Left: E sigil (42px) + wordmark "EMBERHALL" (Cinzel 700, 22px, `.16em`).
- Right nav: text links "Features", "The Hall", "Pricing" (14.5px, `text.body`, hover → `gold.bright`) + **Log In** button.
- **Log In button:** 42px tall, radius 11px, border `1px rgba(217,164,65,.45)`, bg `rgba(217,164,65,.08)`, text `gold.bright` Cinzel 600 14px. Hover bg `rgba(217,164,65,.16)`. Opens login modal.

### Hero (grid: 1fr / .92fr, gap 56px, align center)
**Left column** (animates in: `translateY(14px)`→0, opacity 0→1, .7s ease-out):
- Eyebrow pill: sage-tinted, dot with pulse animation, text "Your table, always lit".
- H1: Cinzel 700, **60px**, line-height 1.04, `#f6ecd9`. Copy: "Keep the **fire** burning between sessions." ("fire" in `gold.bright`, with `<br>` line breaks).
- Sub: Spectral 18px, line-height 1.6, `text.body`, max-width 440px.
- CTAs: **Enter the Hall** (primary gold, 54px tall, radius 13px, Cinzel 700 16px, gradient `#ecc265→#cf962f`, text `#2a1705` — opens login) + **Watch the tour** (ghost: transparent, border `rgba(217,164,65,.3)`, play-triangle icon).
- Social proof: 4 overlapping 34px avatar circles (−9px margin, 2px bg-colored border) + "Trusted by 12,000+ tables across the realms."

**Right column** (floats: `translateY` ±10px, 7s ease-in-out infinite):
- Art card, `aspect-ratio:4/5`, radius 20px, border gold .28, with flickering radial ember glow behind it (`-30px` inset).
- Image fills card; bottom gradient overlay `rgba(13,9,6,.1)→.85`.
- Caption bottom-left: eyebrow "Now playing" → "Ashes of Karth" (Cinzel 700 24px) → "Session 15 · 5 adventurers · next Saturday".

### Feature strip (3-col grid, gap 20px)
Each card: padding 28×26, radius 16, panel gradient, border gold .14 (hover .34). Icon tile 46px radius 12 `rgba(217,164,65,.12)` with `gold.bright` stroke icon. Title Cinzel 600 18px. Body Spectral 14.5px `text.muted`.
1. **Gather the Party** (people icon) — "Track every hero — class, level, hit points and bonds — in one living roster."
2. **Roll in the Open** (d20/cube icon) — "A dice tower built in. d4 to d100, modifiers, crits and a shared roll history."
3. **Keep the Chronicle** (book icon) — "Session notes, the next gathering and the whole saga, remembered between games."

### Footer
Top border gold .12. Left wordmark "EMBERHALL" (Cinzel 13px `.14em`). Right "Gather your party. © 2026 Emberhall."

### Login / Sign-up Modal
- Overlay: `rgba(8,5,3,.78)` + `backdrop-filter:blur(4px)`, centered. Fades/rises in .25s. Click overlay to close; clicks inside stop propagation.
- Panel: max-width 412px, radius 20, gradient `#241710→#160f09`, border gold .3, shadow `0 40px 90px rgba(0,0,0,.7)`. Flickering ember glow above top edge. Close "×" button top-right.
- Header: 52px E sigil → title → subtitle.
- Fields: Email + Password. Each: label (uppercase 12px `.14em` muted) + input 48px tall, radius 11, bg `rgba(12,8,5,.6)`, border gold .2 (focus .6), Spectral 15px.
- "Forgotten your password?" link (right-aligned, `#caa468`).
- Primary submit button (gold, 50px).
- Divider "or" (hairlines + centered label).
- Secondary: "Continue with a Hero token" (ghost button, star icon).
- Footer toggle: switches between **login** and **signup** modes, which swaps title/subtitle/CTA/prompt copy:
  - login → title "Welcome back", sub "The hearth has been kept warm", CTA "Enter the Hall", prompt "New to the table?" / action "Create an account"
  - signup → title "Found your hall", sub "Begin a new legend", CTA "Create account", prompt "Already have a hall?" / action "Log in"

---

## Screen 2 — Campaign Dashboard

**Layout:** flex row. Fixed **84px sidebar** (left) + scrollable **main** (right, `padding:30px 38px 56px`). Main = topbar + content grid (`grid-template-columns: minmax(0,1.95fr) minmax(320px,1fr)`, gap 24px).

### Sidebar (84px)
Vertical column, gradient `#1a130c→#130e09`, right border gold .12.
- Top: 46px E sigil → hairline divider.
- Nav icon buttons (46px square, radius 13): Dashboard, Party, World Map, Codex, Dice, Inventory. Active state: bg `rgba(217,164,65,.16)`, border gold .5, icon `gold.bright`. Inactive icon `#8c8069`, hover → gold.
- Bottom: divider → 42px round "DM" avatar (gradient `#3a2c1c→#241a10`, gold border).

### Topbar
- Left: eyebrow = today's date (long format, uppercase `.32em`) → H1 "Welcome back, Dungeon Master" (Cinzel 600, 34px).
- Right: search field (44px, pill-ish radius 11, magnifier icon, placeholder "Search your realm…", min-width 230px) + **+ New Session** gold button (44px).

### Left column

**Hero campaign card** (height 340px, radius 18):
- Full-bleed image; layered overlays: left-to-right darkening gradient + bottom-right ember radial.
- Content bottom-left (max-width 560px): row of badges — sage "● Active Campaign" pill (pulsing dot) + "SESSION 15". H2 "Ashes of Karth" (Cinzel 700, 42px). Blurb (Spectral 15.5px, `text.body`, max-width 430px): *"The Ember Wraith stirs beneath the drowned city. Five souls stand between the cinders and the dark."* Then **Resume Adventure** gold button (48px, play icon) + "Last played / Saturday, June 21".

**Party roster** (panel card):
- Header: "● The Party · 5 adventurers" (Cinzel 600 19px) + "Manage roster →" link (gold).
- 2-col grid, gap 14. Each member row (padding 14, radius 13, inset bg, hover lifts border to gold .3):
  - 50px medallion (radius 13, Cinzel 700 initials, class-themed gradient bg, colored ring) with a small level badge bottom-right (20px circle, `#15100a`, Cinzel level number in gold.bright).
  - Name (Cinzel 15px, ellipsis) + HP label (right, `tabular-nums`, colored by health) + role (12.5px muted) + HP bar (6px, radius 99, track `rgba(0,0,0,.45)`, fill colored by % ).
  - **HP color logic:** `pct > .6` → sage; `> .3` → gold; else crimson. Ring turns crimson-ish (`rgba(192,86,63,.7)`) when crimson, else `rgba(217,164,65,.4)`.
  - Members (name / role / level / hp / max): Thorne Ashmantle, Dragonborn Paladin, 6, 52/58 · Lyra Wren, Half-Elf Bard, 6, 31/44 · Grik Stonejaw, Mountain Dwarf Fighter, 6, 40/61 · Sylphine Dawnstrider, Wood Elf Ranger, 6, 44/48 · Mortimer Vale, Tiefling Warlock, 5, 9/40 (crimson) · Bronce Ironhide, Human Cleric, 6, 38/45.
  - Medallion gradients (by index): `#6b3f2a→#3a2113`, `#5a3a63→#2f1e36`, `#3f5530→#22301a`, `#2f4a55→#16282f`, `#6a2f2f→#371616`, `#4a4030→#27210f`.

**Chronicle** (activity feed, panel card):
- Header "● Chronicle". List rows separated by top hairline gold .08, each: colored dot (crimson/gold/sage/grey) + text (14.5px `text.body`) + timestamp (12px faint). Entries:
  1. (crimson) "Mortimer Vale dropped to 9 HP against the Ember Wraith — barely clinging to life." — 2 hours ago
  2. (sage… actually gold) "The party uncovered the Sunken Vault beneath the streets of Karth." — 5 hours ago
  3. (sage) "Lyra Wren rolled a natural 20 on Persuasion, swaying the Cinder Court." — Yesterday
  4. (grey) "Session 14 — \"The Drowned Gate\" — concluded after 4 hours." — Yesterday

### Right rail

**Next-session countdown card** (gradient `#2a1c10→#1c1209`, border gold .28):
- Flickering ember radial top-right.
- Eyebrow "Next Gathering" → date string (Cinzel 20px). Computed as the **next Saturday at 7:00 PM** relative to now.
- 3 countdown tiles (Days / Hrs / Min): each radius 12, deep well, big Cinzel 700 26px `gold.bright` number (`tabular-nums`) + uppercase label.
- Footer: 4 overlapping 28px RSVP avatars + "All 5 players confirmed".

**Dice roller** (panel card) — *functional:*
- Header "Dice" + "Modifier +0" label.
- Result face: 128px tall, radius 14, radial gold tint, with a result-colored glow layer. Big Cinzel 700 **54px** number. Detail line below.
  - Idle: "—" / "Choose a die and roll".
  - Rolling: "?" with a shake animation, "The dice tumble…" (≈480ms).
  - Result: total = `1..die + modifier`. Detail e.g. "d20: 14 +2".
  - **Crit (d20 natural 20):** number + glow sage, detail "Critical! Natural 20".
  - **Fail (d20 natural 1):** crimson, "Critical miss — natural 1".
- Die selector: 4-col grid of buttons — d4, d6, d8, d10, d12, d20, d100, Coin (die=2). Selected: gold gradient bg + gold .6 border + light text; unselected: deep well, muted text.
- Modifier stepper (− / value / +, range −20..+20, shown signed e.g. "+0", "−3" using a real minus glyph) + **Roll {die}** gold button.
- History: up to 7 chips, newest first, `tabular-nums`, labelled "d20 › 17". Crit chips sage, fail chips crimson, else default gold-bordered.

**Quick actions** (list card):
- Rows (hover bg `rgba(217,164,65,.08)`): 36px gold icon tile + title (Cinzel 14.5) + sub (12.5 muted) + "›" chevron.
  1. Quick Note / "Jot a session moment" (book icon)
  2. Spawn Encounter / "Roll initiative now" (dice icon)
  3. Open World Map / "Karth & the Cinderlands" (map icon)

---

## Interactions & Behavior
- **Landing:** Log In and both hero CTAs open the modal. Modal toggles login/signup copy in place. Esc/overlay-click closes. Ember particles loop infinitely (decorative). Hero rises on load; art card floats.
- **Dashboard dice roller:** select die → set modifier → Roll. ~480ms "tumble" delay, then result with pop animation; crit/fail special-cased for d20; history capped at 7.
- **Countdown:** recomputes to next Saturday 7 PM; refresh interval ~30s in the prototype (use a timer/`setInterval` or compute on render).
- **Sidebar nav:** active item is state-driven (highlights selected).
- Hover states throughout: gold buttons brighten (`filter:brightness(1.07)`), ghost/borders raise gold alpha, list rows get a faint gold wash.

### Animations (keyframes used)
- `flicker` — opacity 1→.5→.72 over 4–5s (ember glows).
- `pulse` — opacity+scale down at 50% over 2.4s (status dots).
- `rise` — translateY(14px)→0 + fade, .25–.7s ease-out (hero, modal).
- `float` — translateY ±10px, 7s ease-in-out (art card).
- `spark` — translateY 0→−120px, scale 1→.3, fade in then out, 6–11s linear (embers).
- `pop` — scale .6→1.12→1 + fade, .35s (dice result).
- `shake` — small rotate/translate jitter, .48s loop (dice while rolling).

## State Management
- **Landing:** `loginOpen` (bool), `mode` ('login' | 'signup').
- **Dashboard:** `selectedDie` (4/6/8/10/12/20/100/2), `modifier` (−20..20), `result` ({die,base,total,crit,fail} | null), `rolling` (bool), `history` (array, max 7), `activeNav` (index), `now` (timestamp, ticks for countdown).
- Data (campaign, party, activity, RSVPs) is currently hardcoded — wire to your real campaign/character APIs.

## Assets
- **Fonts:** Cinzel + Spectral via Google Fonts (see import above). Substitute with your app's font loading.
- **Icons:** simple inline SVG line icons (home, party/people, map, book, dice/cube, bag, search, play-triangle, star, plus, chevron). Replace with your icon library (Lucide/Heroicons etc.) — match the thin 1.7 stroke weight.
- **Imagery:** campaign/hero art are user-supplied drop slots in the prototype (`<image-slot>`). In production use real `<img>`/background images; the prototype has no bundled art.
- No raster assets are included in this bundle.

## Files
- `Emberhall Landing.dc.html` — landing page prototype (header, hero, features, footer, login modal).
- `Emberhall Dashboard.dc.html` — campaign dashboard prototype (sidebar, hero, party, chronicle, countdown, dice, quick actions).
- `image-slot.js`, `support.js` — prototyping runtime/helpers only; **not** for production. Ignore when implementing.

The two `.dc.html` files open in a browser if you want to see the live behavior, but treat them as references — implement in your app's framework.
