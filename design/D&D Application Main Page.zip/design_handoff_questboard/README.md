# Handoff: QuestBoard — Landing Page ("The Tavern")

## Overview
QuestBoard is a self-hosted web app for running D&D 5e campaigns. This handoff covers the **Landing page** — the "tavern door" that sells the product and routes users into auth. The aesthetic is a warm, lamplit **medieval tavern**: dark oak wood structure, aged parchment content, wrought-iron/gold detailing, ink-brown text, with sparing wax-red and ember-gold accents. Shape language is **angular and iron-bound** (clipped/beveled corners, ~0–4px radii — no pills, no big rounded rectangles).

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype showing the intended look and behavior, **not production code to copy directly**. `QuestBoard Landing.dc.html` is authored in a small in-house "Design Component" format (custom `<x-dc>`, `<sc-for>`, `<sc-if>` tags resolved at runtime by `support.js`, plus a `class Component extends DCLogic` logic block). **Do not ship the .dc.html or support.js.** Your task is to **recreate this design in the target codebase** using its established patterns and libraries.

The brief targets **React + Tailwind CSS**, component-friendly and responsive (desktop-first, still usable on phone), with real accessible controls and thin-line **Lucide** icons. If no environment exists yet, React + Tailwind is the intended stack. Textures are pure CSS (gradients + repeating-linear-gradient); use image slots/placeholders for any user art — no bundled raster art is required.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and interactions below are final. Recreate the UI pixel-close using the codebase's libraries. Exact hex values, fonts, and sizes are given in Design Tokens.

> **Note on auth:** the original written brief called for **OAuth-only** login (Discord + Google, no email/password). This particular prototype iteration instead shows an **email + password form** with a single "Continue with a guild token" social button and a signup/login toggle. Build whichever matches your product decision — the visual treatment of the modal (wood frame + parchment interior + wax-red primary button) is the part to preserve. Both are documented under Screens → Login/Join Modal.

---

## Screens / Views

### 1. Landing Page
A single scrolling page on a dark radial wood-and-hearth background, max content width **1240px**, centered, `44px` horizontal padding throughout. Ambient effects layer behind content: a woodgrain vignette, a faint diagonal grain, and **9 drifting ember particles** rising from the bottom.

Vertical order: **Header → Hero → heraldic divider → "What waits within" features → Footer**. A **Login/Join modal** overlays everything when triggered.

#### Header
- Layout: flex row, space-between, `padding:24px 44px`, `z-index:6`.
- **Left — wordmark lockup:** heraldic crest SVG (`46×46`, gold `#e0a94e`, drop-shadow) + stacked text: "QuestBoard" in **Cinzel Decorative 900, 23px**, letter-spacing `.06em`, color `#f3e6c8`; below it "EST. BY THE TABLE" in **IM Fell English italic, 12px**, letter-spacing `.22em`, color `#a98a5a`.
- **Right — "Log In" button:** `44px` tall, iron-and-gold double-clipped button. Outer layer is a gold gradient `linear-gradient(180deg,#e0b15a,#9c6d20)` with an octagonal `clip-path`; inner layer is dark wood `linear-gradient(180deg,#2a1a0d,#1a0f07)` with a slightly smaller clip, label "Log In" in **Cinzel 600, 14px**, color `#ecc673`. Hover: brighten + gold drop-shadow. Opens the login modal in **login** mode.

#### Hero
- Layout: CSS grid, two columns `minmax(0,1.04fr) minmax(0,.92fr)`, `gap:64px`, vertically centered, `padding:48px 44px 70px`. Collapses to one column on narrow viewports.
- **Left column (copy)** — rises in via `qb-rise .7s`:
  - Eyebrow: centered-flanked rule + "A hearth for every table", IM Fell English italic 16px, `#c89a5a`, letter-spacing `.16em`, with 34px hairline rules on each side.
  - **H1:** "Gather your party / by the *firelight.*" — **Cinzel 700, 58px**, line-height `1.06`, color `#f5e9cd`; the word "firelight." is ember-gold `#ecc673`. Text-shadow `0 2px 30px rgba(0,0,0,.55)`.
  - **Subtext:** EB Garamond 19px, line-height `1.62`, color `#cdba93`, max-width `452px`. Copy: "QuestBoard is the tavern for your table — your campaign, your companions and the next session, all kept warm by the hearth between nights of adventure."
  - **CTA row** (flex, gap 18px, wraps):
    - **Primary — "Enter the Tavern":** `56px` tall, solid gold gradient `linear-gradient(180deg,#e8b85a,#b07d22)`, octagonal clip-path (11px corners), text color `#2a1705` in **Cinzel 700, 16px**, leading Lucide-style home/tavern glyph (`16×16`), gold drop-shadow. Opens modal (signup by default). Hover: brighten + stronger shadow.
    - **Secondary — "Sign the ledger":** same double-clip iron+gold treatment as header button but `56px`, inner label **Cinzel 600, 15px** color `#e6d5af`. Opens modal in **login** mode.
  - **Social proof row** (margin-top 42px): overlapping stack of 4 circular party crests (`36×36`, 2px dark border `#1c120a`, `-9px` overlap, each a diagonal gradient with a single initial in Cinzel 12px) + text "Free for you and your whole party." (15px, `#a8967a`).
- **Right column (title emblem panel)** — rises in via `qb-rise .9s`:
  - **Swaying iron lantern** pinned to top-center: a 2px iron rod, a `34×40` iron lantern box (radius 5–7px, border `#2a1c0e`) glowing, containing a flickering flame teardrop. Lantern group sways `±1.5deg` (`qb-sway 6.5s`); flame pulses (`qb-flame 1.5s`).
  - Radial ember **glow** behind the panel, flickering (`qb-flicker 5s`).
  - **Ornate wood frame:** `13px` padding, gradient `linear-gradient(135deg,#5a3c20,#2c1c0e)`, big drop-shadow + inset gold hairline. Four **gold L-shaped bracket corners** (`26×26`, 3px `#c9a227`).
  - **Oxblood field** inside (`aspect-ratio 4/5`): oxblood radial `#6a2018 → #3a120d → #240a07`, faint horizontal plank texture, inset shadow. Centered content: large crest SVG (`252×252`, gold `#e7bd6a`, glow pulse `qb-sealglow 5.5s`), "QuestBoard" in **Cinzel Decorative 900, 34px** `#f1dca6`, tagline "GATHER · QUEST · RETURN" in IM Fell English italic 16px `#d09a58` letter-spacing `.2em`.
  - **Caption plate** pinned bottom (18px inset): translucent dark bar with a green live-dot (`#8fb15f`, glowing) + "Now gathering" (Cinzel 13px) on the left and "Ashes of Karth · Session 15" (IM Fell English italic 14px `#bfa676`) on the right.

#### Heraldic Divider
Full-width flex row: hairline gradient rule, centered `30×30` crest (`#a87f3a`), hairline gradient rule.

#### "What waits within" — Features
- Centered header: eyebrow "By the hearth you'll find" (IM Fell English italic 16px `#c89a5a`) + H2 "All your table needs, under one roof" (**Cinzel 600, 30px**, `#f3e6c8`).
- **3-column grid**, `gap:22px` (collapses on mobile). Each card: `padding:30px 28px`, dark wood gradient panel with a gold inset hairline (brightens on hover). Contents: `48×48` icon box (gold inset hairline, icon `#e7bd6a`), H3 title (**Cinzel 600, 19px** `#f0e3c5`), body (EB Garamond 16px `#a8967a`).
  - Card 1 — **"Muster the Party"**: "Every hero, hit point and bond, kept on one roster by the fire." (crossed-swords icon)
  - Card 2 — **"Roll by Firelight"**: "A dice tower at the table — d4 to d100, modifiers, crits and all." (dragon icon)
  - Card 3 — **"Keep the Chronicle"**: "Quests, notes and the next gathering, remembered between nights." (scroll icon)

#### Footer
Top hairline `rgba(201,162,39,.16)`, subtle fade background. Flex row space-between: crest (`26×26`) + "QuestBoard" (Cinzel Decorative 700, 15px `#bfa676`) on the left; "Gather your party. © 2026, kept by your table." (IM Fell English italic 14px `#7d6b50`) on the right.

### 2. Login / Join Modal
Fixed full-screen overlay, `z-index:60`, backdrop `rgba(8,4,2,.8)` + `blur(4px)`, click-outside to close. Card centered, `max-width:428px`, enters via `qb-rise .26s`.
- **Wood frame** (same treatment as the emblem panel: `11px` padding, wood gradient, gold bracket corners, big shadow) wrapping a **parchment interior**.
- **Parchment interior:** `padding:36px 36px 32px`, gradient `linear-gradient(158deg,#f3e8ca,#e4d3a6)`, ink text `#3a2c1c`, with two faint radial "stain" blooms. Close **×** button top-right (30×30, ghost, ink `#7a5a32`).
- **Header block:** wax-red crest (`56×56`, `#8b2520`), title + subtitle. Copy is mode-dependent:
  - Signup → title "Join the table" (Cinzel Decorative 700, 24px), sub "Carve your name and gather your party".
  - Login → title "Welcome back, traveller", sub "The hearth has been kept warm".
- **Form** (flex column, gap 15px). Labels are stamped-style: IM Fell English 12px, uppercase, letter-spacing `.18em`, `#7a5a32`. Inputs: `46px` tall, translucent white fill, **inset 1px `#b69a68` border (no radius)**, ink text, EB Garamond 16px; focus tightens border to `#8b6a3a`.
  - "Your name" (text) — **signup mode only** (`sc-if isSignup`).
  - "Email" (email).
  - "Password" (password).
  - **Primary submit:** `52px`, octagonal clip, wax-red gradient `linear-gradient(180deg,#8b2520,#5e1611)`, text `#f3d9c0` Cinzel 700 15px. Label: "Take your seat" (signup) / "Enter the Tavern" (login).
- **"or" divider** (hairlines + italic "or").
- **Social button:** full-width `48px`, ghost fill with inset ink border, wax-red star glyph, "Continue with a guild token". *(Replace with real Discord + Google OAuth buttons if going OAuth-only per the brief.)*
- **Mode switch line:** "Already have a seat? / New to the table?" + underlined toggle button ("Log in" / "Join the table").

---

## Interactions & Behavior
- **Open login:** header "Log In" and hero "Sign the ledger" open the modal in **login** mode; hero primary "Enter the Tavern" opens in **signup** mode (respecting the `signupFirst` flag — see State).
- **Close:** click the backdrop or the × button. Clicks inside the card stop propagation.
- **Mode toggle:** the bottom link swaps signup ↔ login, which swaps the title, subtitle, primary-button label, the presence of the "Your name" field, and the switch prompt/action text.
- **Animations** (all CSS keyframes, defined in the file's `<style>`):
  - `qb-rise` — 16px up + fade, entrance for hero columns (.7s / .9s) and modal (.26s), `ease-out`.
  - `qb-spark` — embers rise 180px, scale down, fade; 7–11s linear loops, staggered delays.
  - `qb-flame` (1.5s) + `qb-flicker` (4–5s) — lantern flame + glow.
  - `qb-sway` (6.5s) — lantern rocks ±1.5deg.
  - `qb-sealglow` (5.5s) — crest drop-shadow pulse.
  - `qb-flicker` — modal top glow.
- **Hover states:** buttons brighten (`brightness(1.05–1.1)`) and deepen their drop-shadow; feature cards intensify the gold inset hairline; ghost buttons darken their fill slightly.
- **Responsive:** hero grid and feature grid collapse to single column on narrow screens; the CTA row and footer wrap. Desktop-first, phone-usable.

## State Management
- `loginOpen: boolean` — modal visibility.
- `mode: 'signup' | 'login'` — drives all mode-dependent copy and the name field.
- Derived: `isSignup = mode === 'signup'`.
- **Prop:** `signupFirst: boolean` (default `true`) — when the generic "Log In"/"Enter the Tavern" entry opens the modal, `true` opens signup, `false` opens login. "Sign the ledger" always opens login.
- No data fetching in the prototype; the form is presentational. Wire submit + OAuth to your auth backend.

## Design Tokens

**Fonts (Google Fonts):**
- Display / headings: **Cinzel** (500/600/700) and **Cinzel Decorative** (700/900).
- Body: **EB Garamond** (400/500/600, + italics).
- Accent / labels / captions: **IM Fell English** (regular + italic).
- (`Grenze Gotisch` is imported but not used in this screen — available for heavier display if needed.)

**Colors:**
- Background wood/hearth radial: `#4a2a12 → #241408 → #140b06`; page base `#120b06`.
- Wood frame gradient: `#5a3c20 → #2c1c0e`; dark wood button: `#2a1a0d → #1a0f07`.
- Parchment: `#f3e8ca → #e4d3a6`; ink text `#3a2c1c` / `#2b2018`.
- Gold accents: `#e0a94e`, `#ecc673`, `#e7bd6a`, `#c9a227` (bracket gold), `#f3e6c8`/`#f5e9cd` (warm cream headings).
- Gold button gradients: `#e8b85a → #b07d22` (solid), `#e0b15a → #9c6d20` (border layer).
- Wax red: `#8b2520 → #5e1611`; oxblood field `#6a2018 → #3a120d → #240a07`.
- Muted text: `#cdba93`, `#a8967a`, `#bfa676`, `#a98a5a`, `#c89a5a`, `#7d6b50`.
- Flame/ember: `#ffd27a`, `#f59a30`, `#d9701f`, `#fff3c0`.
- Live/status green: `#8fb15f`.

**Spacing / layout:** content max-width `1240px`; section h-padding `44px`; hero gap `64px`; feature grid gap `22px`; modal max-width `428px`.

**Radii:** effectively **0** everywhere; corners are cut with `clip-path` octagons (8–11px cuts) or square iron borders. Small hardware radii only on the lantern (5–7px). **No pills, no large rounded rectangles.**

**Shadows:** frame `0 30px 70px rgba(0,0,0,.6)` + `inset 0 0 0 2px rgba(201,162,39,.4)`; button drop-shadows in the `rgba(224,169,78,.34–.5)` gold range; parchment modal `0 40px 90px rgba(0,0,0,.7)`.

**Textures (CSS only):** vignette `radial-gradient(...)`; grain `repeating-linear-gradient(96deg, rgba(0,0,0,.06) 0 2px, transparent 2px 7px)`; plank lines `repeating-linear-gradient(0deg, rgba(0,0,0,.5) 0 1px, transparent 1px 46px)`.

## Assets
- **No raster art required.** All texture is CSS.
- **Heraldic crest** — an inline SVG `<symbol id="qb-crest">` (shield + crossed sword/axe + dragon head), reused at multiple sizes via `<use>`. Recreate as a single React `<Crest/>` component (or an SVG file) and recolor via `currentColor`. Definition is in the .dc.html near the top.
- **Feature + CTA icons** — simple line glyphs; swap for **Lucide** equivalents (e.g. `Swords`, `Dice5`/`ScrollText`, `Scroll`, `Home`).
- **Party crest avatars** — placeholder gradient circles with initials; replace with real user avatars / image slots.
- **Emblem panel + caption** — good candidates for an **image slot** if you later want campaign art behind the crest.

## Files
- `QuestBoard Landing.dc.html` — the design reference (full markup + logic). Read this for exact values, gradients, and copy.
- `support.js` — runtime for the `.dc.html` preview format **only**; not part of the product, do not ship.
