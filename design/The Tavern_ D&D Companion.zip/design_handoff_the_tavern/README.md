# Handoff: The Tavern — D&D 5e Campaign Companion (Landing + Quest Board)

## Overview
"The Tavern" is a self-hosted web app for running D&D 5e campaigns. This handoff covers the two foundational screens that establish the visual system for the whole app:

1. **Landing page** — the "tavern door": marketing hero + OAuth-only login (Discord / Google).
2. **Quest Board** — the signature screen: a wooden board with parchment quest notices nailed to it. The Dungeon Master (DM) posts/manages quests; Players browse and claim them.

Two roles are supported: **Dungeon Master** (create/manage) and **Player** (view/claim). A demo role toggle and screen switcher are included in the prototype for review — they are not production features.

## About the Design Files
The files in this bundle are **design references created in HTML** — a working prototype showing the intended look, feel, and behavior. They are **not** production code to copy directly. `The Tavern.dc.html` uses a small in-house rendering runtime (`support.js`) with a custom template dialect (`<x-dc>`, `<sc-if>`, `<sc-for>`, `{{ }}` holes). **Do not port the runtime.** Instead, recreate these designs in the target codebase's environment using its established patterns.

The brief targets **React + Tailwind CSS**. If that stack exists, use it. If no environment exists yet, React + Tailwind is the recommended choice. All UI uses inline styles in the prototype for streaming reasons — translate those to Tailwind classes / CSS modules as appropriate.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, materials, and interactions are all intentional. Recreate the UI faithfully, including the wood/parchment/iron material treatments. The exact hex values, fonts, and measurements below are authoritative.

---

## Design Language (read first)
The aesthetic is a **warm, lamplit medieval tavern** — lead with **materials, not flat color**:
- **Wood** (dark oak/walnut, visible grain) for structure: headers, frames, the quest-board backing.
- **Parchment** (aged cream/tan vellum with faint stains) for content: notices, panels, modal.
- **Wrought iron / blackened metal** for borders, corner plates, rivets, nailheads.
- **Ink** (dark sepia/brown) for text on parchment.
- **Accents used sparingly:** wax-seal red, forge ember/gold.

**Shape language is ANGULAR, not round.** Buttons and panels feel carved and iron-bound: rectangles with crisp or barely-beveled corners, **radius 0–4px**. No pills, no large rounded rectangles. Use iron bands, nailheads, and bracket/plate corners instead of soft curves. The one deliberate exception is round elements that are physically round: wax seals, nailheads, rivets, status dots.

Keep parchment **warm and readable** — ink on paper, never murky. Avoid "fantasy gold-on-black."

---

## Design Tokens

### Colors
**Wood / structure**
- Wood beam gradient (headers/buttons): `#3c2716` → `#27170c` (vertical)
- Wood button face: `#5a3c22` → `#3a2410`; darker variant `#4a3220` → `#33210f`
- Wood board frame: `#5a3c22` → `#341f0d`; board field `#4c3119` → `#3c2612` → `#301d0e`
- Near-black iron edge / outlines: `#100b07`, `#14100b`, `#1a1611`
- Page background base: `#3a2414` → `#2a1710` → `#1c1008` (vertical)

**Parchment / content**
- Parchment card gradient: `#efe3c6` → `#dcc69d` (150deg)
- Parchment plaque (landing features): `#eaddbf` → `#d8c098`
- Parchment stain radials: `rgba(120,86,42,.13)` and `rgba(90,60,28,.08)`
- Parchment edge/border: `#b39d76`

**Ink (text on parchment)**
- Primary ink: `#2e1d0f` (titles), `#3a2616` (body-strong), `#4a3320` (values)
- Secondary ink: `#5c4528` (body), `#9a703a` (parchment labels)

**Cream (text on wood)**
- Headline cream: `#f3e7cb`, `#efe2c6`
- Ember/gold accent text: `#d6a64f`, `#c9a96b`, `#e7b35e`
- Muted label on wood: `#9c7b46`, `#8f7a55`

**Accents**
- Wax red: `#7a201b` (default), alt `#8b2c1f`, `#6e1f1c`
- Forge ember/gold: `#d6a64f` (default), alt `#c9882f`, `#b8923a`

**Difficulty scale** (each: light / base / dark for the wax seal radial)
- Trivial: `#7e8c6d` / `#5f6b52` / `#39412f` (muted olive-grey)
- Easy: `#6f9051` / `#4d6b39` / `#2e4221` (green)
- Medium: `#d8a44e` / `#b07a2e` / `#6e4a18` (amber/gold)
- Hard: `#cd7644` / `#a8552a` / `#6b3417` (rust/orange)
- Deadly: `#9e3b34` / `#6e1f1c` / `#3f0f0e` (blood red)

**Status colors** (used for status tab + claimed-by accent)
- Available: `#7c5a2e`
- Active / Claimed: `#8a5a1f`
- Completed: `#3f5a30`
- Failed: `#6e1f1c`

### Typography (Google Fonts)
- **Logo / wordmark:** `Pirata One` (blackletter) — the tavern-sign name.
- **Display / headings:** `Cinzel Decorative` (700/900) — hero headline, quest titles, board title.
- **Subheadings / UI labels / buttons:** `Cinzel` (400–700) — uppercase, wide letter-spacing (2–5px) for stamped-lettering feel.
- **Body:** `Spectral` (300–600, incl. italic) — ink-on-parchment reading text.
- Small labels: `Cinzel`, ~9–11px, UPPERCASE, letter-spacing 1.5–4px.

Load: `Pirata+One`, `Cinzel+Decorative:wght@400;700;900`, `Cinzel:wght@400;500;600;700`, `Spectral:ital,wght@0,300..600;1,400;1,500`.

### Spacing / shape
- Border radius: 2px (buttons, tabs, panels), 3–4px (frames, cards, modal). **Never more.**
- Card padding: ~24px 22px 20px.
- Board frame: 14px wood border + inner iron inset ring, padding ~36px 30px 44px.
- Button "carved" 3D: `box-shadow: inset 0 1px 0 rgba(255,220,170,.2), 0 4px 0 <darker>, 0 8px 16px rgba(0,0,0,.5)` (the `0 Ypx 0` hard shadow gives the pressed-wood edge).

### Shadows / materials (recipes)
- **Wood plank field (board backing):** layer three backgrounds — horizontal plank seams `repeating-linear-gradient(180deg, transparent 0 92px, rgba(0,0,0,.5) 92-94px, rgba(150,100,52,.22) 94-97px)`, fine horizontal grain `repeating-linear-gradient(180deg, rgba(255,214,158,.03) 0 3px, transparent 3-7px, rgba(58,36,16,.09) 7-8px, transparent 8-14px)`, plus a vertical color-variation gradient and the base vertical gradient.
- **Wood wall (page bg):** faint fine grain `repeating-linear-gradient(90deg, rgba(255,190,120,.022) 0 3px, transparent 3-9px, rgba(0,0,0,.07) 9-10px, transparent 10-17px)` + wide plank seams every 146–149px + base gradient + a top ember radial `radial-gradient(ellipse 120% 80% at 50% -10%, rgba(214,150,70,.13), transparent 55%)`.
- **Wax seal (difficulty):** 54px circle, `radial-gradient(circle at 40% 34%, <light>, <base> 60%, <dark>)`, `border: 2px solid <dark>`, `box-shadow: 0 3px 7px rgba(0,0,0,.4), inset 0 0 0 3px rgba(255,255,255,.14), inset 0 2px 3px rgba(255,255,255,.32), inset 0 -5px 8px rgba(0,0,0,.38)`, rotated `-5deg`. Label inside: Cinzel 9px uppercase `#f6ead0`.
- **Nailhead / rivet:** small circle `radial-gradient(circle at 36% 30%, #9a8c79, #2a241d 58%, #100d0a)` + `inset 0 1px 1px rgba(255,255,255,.4)`.
- **Iron corner plate (modal):** 24px square, radius 2px, `radial-gradient(circle at 50% 50%, #6b6157 0 2px, transparent 2.6px), linear-gradient(135deg, #2c2720, #100d0a)` — the radial makes a centered rivet.

---

## Screens / Views

### Screen 1 — Landing page ("the tavern door")
**Purpose:** sell the app and get the user into OAuth login.

**Layout:** full-height column on the wood-wall background.
- **Header** (wood beam, `#3c2716→#2a1a0e`, 3px `#100b07` bottom border): left = small rivet + `THE TAVERN — EST. OF THE REALM` (Cinzel, 13px, letter-spacing 4px, `#c9a96b`). Right = **Log In** button (wood, carved 3D, Cinzel 13px uppercase).
- **Hero** (centered column):
  - **Hanging tavern sign** — a horizontal iron mounting bar, two riveted chains, and a carved wood board (`#4a3017→#35200e`, 4px `#14100b` border, inner ember rule + 4 corner nailheads) that reads `THE` (Cinzel, `#9c7b46`) over **Tavern** (Pirata One, 62px, `#d6a64f`). The board gently **sways** (`rotate(-2.2deg)↔2.2deg`, ~5.5s ease-in-out infinite; use `transform-origin: top center`; the mount bar stays fixed).
  - **Headline:** "Gather your party. / The board awaits." — Cinzel Decorative 900, clamp(34px,5.4vw,62px), `#f3e7cb`.
  - **Subtext:** one paragraph, Spectral, clamp(15–19px), `#cdbb98`, max-width ~54ch.
  - **CTA:** "Enter the Tavern" — large wood button with a Lucide `log-in` icon (ember stroke), opens the login modal.
  - Small caption: "No password to forge — sign in with Discord or Google."
  - **Three parchment feature plaques** (responsive grid, `minmax(220px,1fr)`): each a parchment card, 2px iron border, Lucide line icon (`#7a4f22`), Cinzel uppercase title, Spectral body. Titles: "A Living Board", "Spoils Tracked", "Share a Code".

### Login Modal (from Landing CTA / header Log In)
**Purpose:** OAuth-only sign-in. **NO email/password fields.**
- Overlay `rgba(12,7,3,.72)` + slight blur; click-outside closes.
- Parchment panel, max-width 420px, 4 iron corner plates (see recipe), close ✕ (Lucide, `#8a6a3a`).
- Eyebrow "CROSS THE THRESHOLD" (Cinzel), title "Enter the Tavern" (Cinzel Decorative 900, 28px), italic Spectral subtext.
- **Sign in with Discord** — Discord-blurple button `#5b63d8→#3f47b8`, 2px `#1a1530` border, official Discord glyph (light fill), carved 3D shadow `0 4px 0 #2a2f7a`.
- **Sign in with Google** — light parchment button `#f6efe0→#e0d0aa`, 2px `#8a6a3a`, official multi-color Google "G", carved 3D `0 4px 0 #b39564`.
- Footer microcopy, Spectral 12.5px.
- Both buttons, in the prototype, navigate to the Quest Board (stand-ins for the real OAuth redirect).

### Screen 2 — Quest Board (signature screen)
**Purpose:** DM posts/manages quests; players browse and claim.

**App header** (sticky, wood beam):
- **Mini hanging sign** (same treatment, smaller, `swayslow`).
- **Campaign** eyebrow + campaign name (Cinzel Decorative, e.g. "Embers of the Sundered Crown").
- **Role badge** — pill-free wood chip with a status dot (wax-red for DM, green for Player) + role label. (In the prototype this is a demo toggle; in production it reflects the signed-in user's role and is not clickable to change.)
- **Right cluster (DM):** an **Invite code** chip (parchment, shows code e.g. `OAK-3F9-RAVEN`, copy icon, "Copied" confirmation) + **Post a Quest** wood button (Lucide `plus`).
- **Right cluster (Player):** a parchment chip "N claimed by you".

**Board frame:** thick wood border + iron inset ring + 4 iron corner brackets; the field is the **horizontal wooden-plank** texture (recipe above). Inside:
- **Board header strip:** "The Quest Board" (Cinzel Decorative 900, clamp 24–34px, `#e7d3a6`) + count line "N open · N afoot" (Cinzel uppercase, `#9c7b46`), with a 2px `rgba(201,169,107,.22)` divider.
- **Empty state:** centered Lucide clipboard icon + "No quests posted" (Cinzel Decorative 24px) + italic "— the board awaits. —".
- **Notices grid:** `repeat(auto-fill, minmax(312px, 1fr))`, gap 34px 26px. Each notice is slightly **rotated** (±~1–2deg, per-quest) for a pinned-by-hand look.

**Quest notice (parchment card)** — contents top to bottom:
1. **Nailhead** centered at the top edge (overlapping, z above card).
2. **Status tab** (only when status ≠ available) — a small angular stamped tab in normal flow *above* the title: status dot + status label (Cinzel 10px uppercase, white on the status color). It has `margin-right: 56px` so it never collides with the seal. **Important:** this must sit in normal flow above the title — an earlier diagonal corner-ribbon version clipped the title text; do not reintroduce that.
3. **Difficulty wax seal** — absolutely positioned top-right (`top:15px; right:15px`, 54px, rotated `-5deg`), color-coded by difficulty (see tokens), label inside.
4. **Title** — Cinzel Decorative 700, 21px, `#2e1d0f`, `margin-right: 56px` to clear the seal.
5. **Meta rows** — "GIVER" (Lucide `user`) and "WHERE" (Lucide `map-pin`): tiny Cinzel uppercase label `#9a703a` + value `#4a3320`.
6. **Description** — Spectral 14px, `#5c4528`.
7. **Torn divider** — dashed rule `repeating-linear-gradient(90deg, #9a805a 0 6px, transparent 6-11px)`.
8. **Rewards** — "REWARD" label, then a wrap of reward tags. Each tag: 1.5px `#7c5a2e` border, faint fill, a **Lucide icon per reward type** (gold→`circle-dollar`/coins, item→`package`, xp→`sparkles`/`star`, reputation→`shield`, other→`gem`), a small type label, and the value (e.g. "200 gp", "Cloak of Elvenkind", "700", "+2 Temple").
9. **Claimed-by** (when claims exist) — a left-accent bar in the status color, Lucide `users`, "CLAIMED BY" label + comma-joined names.
10. **Actions row:**
    - **Player, available:** "Claim Notice" (dark wood button, Lucide `hand`/torch icon).
    - **Player, claimed by me:** "Release" (parchment button, Lucide `x`).
    - **Player, active but not mine:** "Spoken For" (dashed disabled state).
    - **DM (always):** three iron icon buttons — Edit (Lucide `pencil`), Change status (Lucide `flag`/banner, cycles available→active→completed→failed), Remove (Lucide `trash`, red-tinted). DM does not see Claim/Release.
11. **Aged veil** — completed/failed notices get a translucent dark overlay `linear-gradient(160deg, rgba(60,38,18,.34), rgba(40,24,10,.42))` to read as "done".

---

## Interactions & Behavior
- **Landing → Login:** header "Log In" and hero "Enter the Tavern" both open the login modal. Overlay click or ✕ closes it. Both OAuth buttons trigger the OAuth flow (prototype: navigate to Quest Board).
- **Role display:** header shows DM or Player badge. Player and DM see different actions (see actions row). In production, role comes from the campaign membership; the prototype's toggle is for review only.
- **Claim (Player):** on an available quest → status becomes `active`, quest gains a claim `{name: currentUser}`, `claimedByMe = true`, "Release" replaces "Claim". 
- **Release (Player):** removes the current user's claim; status returns to `available` if no claims remain, else stays `active`.
- **Post a Quest (DM):** pins a new notice at the top of the board (prototype seeds an editable placeholder quest; production opens a create form).
- **Edit / Change status / Remove (DM):** edit metadata; cycle status through available→active→completed→failed; delete the notice.
- **Invite code (DM):** click copies the code to clipboard and shows a transient "Copied" confirmation (~1.6s).
- **Empty state:** when there are no quests, show the "No quests posted — the board awaits" panel.
- **Micro-animation:** the hanging signs sway continuously (`@keyframes sway` / `swayslow`), `transform-origin: top center`. Purely decorative; safe to gate behind `prefers-reduced-motion`.

## State Management
Per the brief's data model:
- **Quest:** `{ id, title, description, giver, location, difficulty(trivial|easy|medium|hard|deadly), status(available|active|completed|failed), rewards[{type, label, value}], claims[{name}], claimedByMe(bool) }` (`rot` is a prototype-only per-card rotation for visual flavor).
- **Campaign:** `{ name, inviteCode, role(dm|player) }`.
- **Derived/UI state:** current screen (landing/board), login modal open, "copied" flash, counts (available/active), my-claim count.
- **Transitions:** claim/release mutate a quest's `status`/`claims`/`claimedByMe`; DM cycle mutates `status`; post adds a quest; remove filters it out.
- **Data:** in production, quests and campaign come from the server; claims and status changes should be optimistic-updated then persisted. OAuth (Discord/Google) provides identity.

## Icons
Thin-line **Lucide** icons throughout (affordances only): `log-in`, `plus`, `copy`, `check`, `user`, `map-pin`, `users`, `pencil`, `flag`, `trash-2`, `x`, `hand`, `clipboard`, plus reward-type icons `coins`/`circle-dollar-sign`, `package`, `sparkles`/`star`, `shield`, `gem`. The Discord and Google marks are the official brand glyphs (inline SVG), not Lucide.

## Assets
- **No bundled raster art required.** All materials (wood, parchment, iron, seals) are pure CSS gradients + texture. 
- Use **image slots / placeholders** for any user-provided art (campaign banner, avatars) if/when added — none are required for these two screens.
- Fonts: Google Fonts (Pirata One, Cinzel Decorative, Cinzel, Spectral).

## Files
- `The Tavern.dc.html` — the full prototype (both screens + login modal). Contains all exact styles, sample D&D content (8 quests spanning every difficulty and status), and the interaction logic. This is the source of truth for colors, spacing, and copy.
- `support.js` — the prototype runtime **for reference only; do not port it.**

Open `The Tavern.dc.html` in a browser to interact with the live reference. Use the bottom "Demo" switcher to move between the Tavern Door (landing) and the Quest Board, and the header role badge to preview DM vs Player.
